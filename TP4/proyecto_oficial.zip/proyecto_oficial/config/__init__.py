
# Configuraciones generales

debug = 1 # Nos dice si mostramos o no los print del programa
max_n = 20
# coding=utf-8

from aprox.legendre import Legendre

from aprox import Aprox
from numpy.polynomial import legendre as L
from math import sqrt
import sympy as sp
from utils import algebra
from numpy import polynomial as P
import numpy as np

#legendre = Legendre(None)

#legendre.calcular(5)

# for i in range(1,10):
#     print("calculo ",i)
#     legendre.calcular(i)
